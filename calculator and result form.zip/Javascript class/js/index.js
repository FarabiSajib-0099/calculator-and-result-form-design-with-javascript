function pepsi_frst() {

   document.getElementById('pepsi-img').src = "img/pepsi001.png";
   document.getElementsByClassName('main-page')[0].style.backgroundColor = "red";
   document.getElementById('h2-text').innerHTML = "Welcome To Our Website.";
}

function pepsi_sec() {

   document.getElementById('pepsi-img').src = "img/pepsi002.png";
   document.getElementsByClassName('main-page')[0].style.backgroundColor = "green";
}

function pepsi_thrd() {

   document.getElementById('pepsi-img').src = "img/pepsi003.png";
   document.getElementsByClassName('main-page')[0].style.backgroundColor = "#000";

};

function result() {
   var exam = document.getElementById('exam').value;
   var year = document.getElementById('year').value;
   var board = document.getElementById('board').value;
   var roll = document.getElementById('roll').value;
   var reg = document.getElementById('reg').value;
   var value_s = document.getElementById('value_s').value;
  
   document.getElementById('exam-value').innerHTML = exam;
   document.getElementById('year-value').innerHTML = year;

   document.getElementById('board-value').innerHTML = board;
   document.getElementById('reg-value').innerHTML = reg;
   document.getElementById('roll-value').innerHTML = roll;
   document.getElementById('ans-value').innerHTML = value_s;



}


function reset() {
   document.getElementById('exam').value ='ssc'
   document.getElementById('year').value ='0000'
   document.getElementById('board').value =''
   document.getElementById('roll').value =''
   document.getElementById('reg').value =''
   document.getElementById('value_s').value =''





}

function screen(val)
        {
        document.getElementById("box").value=val;
        }


function shownum(val)   {
        document.getElementById("box").value+=val;
        }

function solve() { 
    try     { 
            screen(eval(document.getElementById("box").value)) 
            } 
    catch(e) {
            screen('Error') 
            } 
                 }
function clearme() {
                document.getElementById("box").value = "";
                } 

function delback() {
                var valueNeeded = document.getElementById("box").value;
                var finalValueNeeded = valueNeeded.substr(0, valueNeeded.length-1); 
                document.getElementById("box").value=finalValueNeeded;
                
                } 